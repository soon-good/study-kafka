package io.study.springkafkastart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringKafkaStartApplicationTests {

	@Test
	void contextLoads() {
	}

}
